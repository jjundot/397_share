import os
import platform
import setuptools
import subprocess
import sys
import zipfile
import re
import json
import tempfile
from packaging.version import parse
from packaging.version import Version
from setuptools.command.install import install as _install
from wheel.bdist_wheel import bdist_wheel as _bdist_wheel

PACKAGE_NAME = "cpm_kernels"
build_version="1.0.11+ppu1.7.0"
edition_type='ce'
USE_MANYLINUX = True
framework = "torch"
BASE_WHEEL_URL = "https://art-pub.eng.t-head.cn/artifactory/ptgai-pypi_ppu_generic/{pkg_name}/{version}/{whl_name}"
JSON_URL = "https://art-pub.eng.t-head.cn/artifactory/ptgai-pypi_ppu_generic/{pkg_name}/index.json"
g_wheel_url = ""
g_wheel_filename = ""
g_best_matching_build_version = ""

def run_cmd(cmd: str, timeout=300, stdout=subprocess.PIPE, stderr=subprocess.PIPE):
    ret = subprocess.run(args=cmd, shell=True, stdout=stdout, stderr=stderr, encoding="utf-8")
    return ret

def get_os_name():
    cmd = "cat /etc/os-release"
    ret = run_cmd(cmd)
    if ret.returncode !=0:
        print("Fail to get OS type!!!")
        os_name="any"
    else:
        output = ret.stdout
        if "Ubuntu" in output and "20.04" in output:
            os_name="ubuntu2004"
        elif "Ubuntu" in output and "22.04" in output:
            os_name="ubuntu2204"
        elif "Ubuntu" in output and "24.04" in output:
            os_name="ubuntu2404"
        elif "alios" in output:
            os_name="alios7u2"
        elif USE_MANYLINUX:
            print("This package is build in manylinux, use os alios7u2.")
            os_name="alios7u2"
        else:
            print("os_name unsupported!!")
            os_name="any"
    return os_name

def get_platform():
    """
    Returns the platform name as used in wheel filenames.
    """
    if sys.platform.startswith("linux"):
        return "linux_x86_64"
    elif sys.platform == "darwin":
        mac_version = ".".join(platform.mac_ver()[0].split(".")[:2])
        return f"macosx_{mac_version}_x86_64"
    elif sys.platform == "win32":
        return "win_amd64"
    else:
        raise ValueError("Unsupported platform: {}".format(sys.platform))

def get_framework_version():
    if framework == '' or framework is None:
        return ""
    if framework == 'torch':
        try:
            import torch
            torch_version_raw = parse(torch.__version__)
            try:
                torch_version = f"{torch_version_raw.major}.{torch_version_raw.minor}.{torch_version_raw.micro}"
            except AttributeError:
                torch_version = str(torch_version_raw).split("+")[0]
            return torch_version
        except Exception as e:
            print(f"Import torch failed: {e}")
            exit(1)
    else:
        try:
           import importlib
           __sail_framework = importlib.import_module(framework)
           return __sail_framework.__version__
        except Exception as e:
           print(f"Import framework {framework} failed: {e}")
           return ""

def get_cuda_version_by_nvcc():
    try:
        result = subprocess.run(['nvcc', '--version'],
                                stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE,
                                text=True,
                                check=True)
        output = result.stdout
        # example: Cuda compilation tools, release 12.2, V12.2.140
        match = re.search(r'release (\d+\.\d+)', output)
        if match:
            version = match.group(1)  # 12.2
            print(f"Get cuda version by nvcc --version: {output}")
            return version
        else:
            print(f"Miss match cuda version by nvcc --version: {output}")
            return None
    except Exception as e:
        print(f"Unexpected error for nvcc --version: {e}")
        return None

def get_cuda_version_by_env():
    try:
        # CUDA_SDK_VER=cuda-12.8
        output = os.getenv('CUDA_SDK_VER')
        if output is not None and 'cuda-' in output:
            print(f"Get cuda version by env 'CUDA_SDK_VER': {output}")
            return output.split('-')[1]
        else:
            print(f"Can not get env 'CUDA_SDK_VER': {output}. Example: CUDA_SDK_VER=cuda-12.8")
            return None
    except Exception as e:
        print(f"Unexpected error for get env CUDA_SDK_VER: {e}")
        return None

def get_sdk_version_by_env():
    try:
        # SDK_VESION_FOR_PYPI=1.7.0
        output = os.getenv('SAIL_PYPI_SDK_VESION')
        if output is not None:
            print(f"Get sdk version by env 'SAIL_PYPI_SDK_VESION': {output}")
            return output
        else:
            print(f"Can not get env 'SAIL_PYPI_SDK_VESION': {output}. Example: SAIL_PYPI_SDK_VESION=1.7.0")
            return None
    except Exception as e:
        print(f"Unexpected error for get env SAIL_PYPI_SDK_VESION: {e}")
        return None

def get_cuda_version():
    if framework == 'torch':
        try:
            import torch
            torch_cuda_version = parse(torch.version.cuda)
            try:
                cuda_version = f"{torch_cuda_version.major}{torch_cuda_version.minor}"
                print("Get cuda version from torch.version.cuda major + minor")
            except AttributeError:
                cuda_version = str(torch_cuda_version).replace(".", "")
                print("Get cuda version from torch.version.cuda")
            return cuda_version
        except Exception as e:
            print(f"Import torch failed: {e}")
            exit(1)
    else:
        cuda_version = get_cuda_version_by_nvcc()
        if cuda_version is None:
            cuda_version = get_cuda_version_by_env()
        if cuda_version is None:
            return None
        return cuda_version.replace(".", "")
    
def get_wheel_url():
    global g_wheel_url
    global g_wheel_filename
    try:
        g_wheel_url, g_wheel_filename = get_wheel_url_new()
    except Exception as e:
        g_wheel_url, g_wheel_filename = None, None
        print(f"Unexpected error in get_wheel_url_new. Error: {e}")
    if g_wheel_url is None or g_wheel_filename is None or g_wheel_url == "" or g_wheel_filename == "":
        # g_wheel_url, g_wheel_filename = get_wheel_url_old()
        print(f"No installation package compatible with the current environment was found.")
        exit(1)
    return g_wheel_url, g_wheel_filename

def get_wheel_url_old():
    global g_best_matching_build_version
    g_best_matching_build_version = build_version
    python_version = f"cp{sys.version_info.major}{sys.version_info.minor}"
    platform_name = get_platform()
    os_name = get_os_name()
    package_version = build_version.split("+")[0]
    framework_version = get_framework_version()
    cuda_version = get_cuda_version()
    print("Get whl url with local config.")
    global g_wheel_filename
    if framework != "" and framework_version is not None:
        # Determine wheel URL based on CUDA version, framework version, python version and OS
        g_wheel_filename = f"{PACKAGE_NAME}-{package_version}+cu{cuda_version}{framework}{framework_version}{os_name}{edition_type}-{python_version}-{python_version}-{platform_name}.whl"
        wheel_url = BASE_WHEEL_URL.format(pkg_name=PACKAGE_NAME, version=build_version, whl_name=g_wheel_filename)
        print(f"Whl with framework is wheel_url: {wheel_url}")
        return wheel_url, g_wheel_filename
    else:
        # Determine wheel URL based on CUDA version, python version and OS
        g_wheel_filename = f"{PACKAGE_NAME}-{package_version}+cu{cuda_version}{os_name}{edition_type}-{python_version}-{python_version}-{platform_name}.whl"
        wheel_url = BASE_WHEEL_URL.format(pkg_name=PACKAGE_NAME, version=build_version, whl_name=g_wheel_filename)
        print(f"Whl is wheel_url: {wheel_url}")
        return wheel_url, g_wheel_filename

def get_local_sdk_version():
    try:
        result = subprocess.run(['clang', '--version'],
                                stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE,
                                text=True,
                                check=True)
        output = result.stdout
        print(f"clang --version: {output}")
        # example: clang version 13.0.1 (2.0.0-d68756)
        match = re.search(r'\(([^)]+)\)', output)
        if match:
            version = match.group(1)  # 2.0.0-d68756
            if '-' in version:
                return version.split('-')[0]
            return version
        else:
            return None
    except Exception as e:
        print(f"Unexpected error for clang --version: {e}")
        return None

def get_best_matching_release_version(release):
    if release is None:
        return None
    local_sdk_version = get_local_sdk_version()
    if local_sdk_version is None:
        local_sdk_version = get_sdk_version_by_env()
    print(f"local_sdk_version is {local_sdk_version}")
    if local_sdk_version is None:
        return None
    sdk_map = release.get("sdk", {})
    try:
        local_sdk_version_obj = Version(local_sdk_version)
        local_sdk_version_base_obj = Version(local_sdk_version_obj.base_version)
        pre_sdk_version = []
        after_sdk_version = []
        SAIL_PYPI_BUILD_WITH_SDK_VERSION = os.getenv("SAIL_PYPI_BUILD_WITH_SDK_VERSION")
        if SAIL_PYPI_BUILD_WITH_SDK_VERSION:
            if SAIL_PYPI_BUILD_WITH_SDK_VERSION not in sdk_map.keys():
                print(f"Error: can not found a matching wheel build with SAIL_PYPI_BUILD_WITH_SDK_VERSION: {SAIL_PYPI_BUILD_WITH_SDK_VERSION}")
                sys.exit(1)
            else:
                print(f"Use a matching wheel build with SAIL_PYPI_BUILD_WITH_SDK_VERSION: {SAIL_PYPI_BUILD_WITH_SDK_VERSION}")
                return SAIL_PYPI_BUILD_WITH_SDK_VERSION
        for sdk_version, support_versions in sdk_map.items():
            try:
                current_sdk_version_obj = Version(sdk_version)
                current_sdk_version_base_obj = Version(current_sdk_version_obj.base_version)
                if current_sdk_version_base_obj <= local_sdk_version_base_obj:
                    pre_sdk_version.append({"version_obj": current_sdk_version_obj, "sdk_version": sdk_version, "support_versions": support_versions})
                else:
                    after_sdk_version.append({"version_obj": current_sdk_version_obj, "sdk_version": sdk_version, "support_versions": support_versions})
            except Exception as e:
                # print(f"Error: Get Version failed: {e}, for {release}")
                continue
        pre_sdk_version.sort(key=lambda x: x['version_obj'], reverse=True)
        for one_pre_sdk_version in pre_sdk_version:
            current_version = one_pre_sdk_version.get("sdk_version", "")
            support_versions = one_pre_sdk_version.get("support_versions", [])
            if len(support_versions) == 0 or local_sdk_version in support_versions:
                return current_version
        SAIL_PYPI_FALLBACK_ORDER = os.getenv("SAIL_PYPI_FALLBACK_ORDER")
        if SAIL_PYPI_FALLBACK_ORDER and SAIL_PYPI_FALLBACK_ORDER in ['oldest', 'newest']:
            if SAIL_PYPI_FALLBACK_ORDER == 'oldest':
                after_sdk_version.sort(key=lambda x: x['version_obj'])
            if SAIL_PYPI_FALLBACK_ORDER == 'newest':
                after_sdk_version.sort(key=lambda x: x['version_obj'], reverse=True)
            for one_after_sdk_version in after_sdk_version:
                current_version = one_after_sdk_version.get("sdk_version", "")
                support_versions = one_after_sdk_version.get("support_versions", [])
                if len(support_versions) == 0 or local_sdk_version in support_versions:
                    return current_version
        return None
    except Exception as e:
        return None

def get_wheel_url_new():
    wheel_url, wheel_filename = "", ""
    python_version = f"cp{sys.version_info.major}{sys.version_info.minor}"
    platform_name = get_platform()
    os_name = get_os_name()
    package_version = build_version.split("+")[0]
    framework_version = get_framework_version()
    cuda_version = get_cuda_version()
    print(f"Try to get whl url with index.json. python: {python_version}, platform_name: {platform_name}, os: {os_name}, package_version: {package_version}, framework: {framework}, framework_version: {framework_version}, cuda: {cuda_version}")
    json_url = JSON_URL.format(pkg_name=PACKAGE_NAME)
    print(f"Index.json url is {json_url}")
    oe_release = None
    ce_release = None
    with tempfile.TemporaryDirectory(dir="/tmp") as temp_dir:
        if "aiext" in json_url:
            download_file_with_curl(file_url=json_url, filename="index.json", temp_file_path=temp_dir)
        else:
            download_file(file_url=json_url, filename="index.json", temp_file_path=temp_dir)
        file_path = os.path.join(temp_dir, "index.json")
        if not os.path.exists(file_path):
            print(f"Can not find index.json in ${file_path}")
            return "", ""
        with open(file_path, "r") as f:
            json_data = json.load(f)
            releases = json_data.get("release", [])
            for release in releases:
                if release.get("version", "") == package_version and \
                release.get("cuda", "") == f"cu{cuda_version}" and \
                release.get("python", "") == python_version and \
                release.get("os", "") == os_name and \
                release.get("edition", "") == edition_type and \
                (framework_version is None or framework_version == "" or release.get("torch", "") == framework_version):
                    if release.get("edition", "") == "oe":
                        oe_release = release
                    if release.get("edition", "") == "ce":
                        ce_release = release
    global g_best_matching_build_version
    best_matching_sdk_version = None
    if oe_release is not None:
        best_matching_sdk_version = get_best_matching_release_version(oe_release)
        g_best_matching_build_version = f"{package_version}+ppu{best_matching_sdk_version}" if best_matching_sdk_version is not None else ""
        if ".oe" in build_version:
            g_best_matching_build_version = f"{package_version}+ppu{best_matching_sdk_version}.oe" if best_matching_sdk_version is not None else ""
        print(f"Best matching oe release is: {oe_release}, best matching sdk version is: {best_matching_sdk_version}, best matching build version is: {g_best_matching_build_version}")
    if best_matching_sdk_version is None and ce_release is not None:
        best_matching_sdk_version = get_best_matching_release_version(ce_release)
        g_best_matching_build_version = f"{package_version}+ppu{best_matching_sdk_version}" if best_matching_sdk_version is not None else ""
        if ".ce" in build_version:
            g_best_matching_build_version = f"{package_version}+ppu{best_matching_sdk_version}.ce" if best_matching_sdk_version is not None else ""
        print(f"Best matching ce release is: {ce_release}, best matching sdk version is: {best_matching_sdk_version}, best matching build version is: {g_best_matching_build_version}")
    if best_matching_sdk_version is None:
        g_best_matching_build_version = ""
        print(f"Can not get best matching sdk version.")
        return "", ""
    if framework != "" and framework_version is not None:
        wheel_filename = f"{PACKAGE_NAME}-{package_version}+cu{cuda_version}{framework}{framework_version}{os_name}{edition_type}-{python_version}-{python_version}-{platform_name}.whl"
        wheel_url = BASE_WHEEL_URL.format(pkg_name=PACKAGE_NAME, version=g_best_matching_build_version, whl_name=wheel_filename)
        print(f"Best matching whl with framework is wheel_url: {wheel_url}")
        return wheel_url, wheel_filename
    else:
        wheel_filename = f"{PACKAGE_NAME}-{package_version}+cu{cuda_version}{os_name}{edition_type}-{python_version}-{python_version}-{platform_name}.whl"
        wheel_url = BASE_WHEEL_URL.format(pkg_name=PACKAGE_NAME, version=g_best_matching_build_version, whl_name=wheel_filename)
        print(f"Best matching whl is wheel_url: {wheel_url}")
        return wheel_url, wheel_filename

def download_file(file_url, filename, temp_file_path=None):
    file_path = os.path.abspath(filename)
    if temp_file_path is not None:
        file_path = os.path.join(temp_file_path, filename)
    else:
        print(f"Guessing wheel URL: {file_url}")
    output = []
    try:
        # Attempt to download the wheel package with password and user.
        username = "ai_sw_guest"
        password = "Pass1234"
        cmd = f"wget --user={username} --password={password} -O {file_path} {file_url}"
        ret = run_cmd(cmd)
        output = ret.stdout.splitlines() + ret.stderr.splitlines()
        if ret.returncode == 0:
            if os.path.exists(file_path):
                return file_path
            else:
                print("File not found: " + str(file_path))
                print("Unknown Error! Please check environment or contact PTG IT Team.")
                for line in output:
                    print(line)
                exit(1)
        else:
            print(f"Attempt to download the file: {file_url} failed.")
            for line in output:
                print(line)
            if temp_file_path is not None:
                return file_path
            exit(1)
    except Exception as e:
        print(f"An error occurred in download_file: {e}")
        exit(-1)

def download_file_with_curl(file_url, filename, temp_file_path=None):
    file_path = os.path.abspath(filename)
    if temp_file_path is not None:
        file_path = os.path.join(temp_file_path, filename)
    else:
        print(f"Guessing wheel URL: {file_url}")
    output = []
    try:
        # Attempt to download the wheel package with password and user.
        cmd = f"curl -L --netrc -o {file_path} {file_url}"
        ret = run_cmd(cmd)
        output = ret.stdout.splitlines() + ret.stderr.splitlines()
        if ret.returncode == 0:
            if os.path.exists(file_path):
                return file_path
            else:
                print("File not found for curl: " + str(file_path))
                print("Unknown Error for curl! Please check environment or contact PTG IT Team.")
                for line in output:
                    print(line)
                exit(1)
        else:
            print(f"Attempt to download the file with curl: {file_url} failed.")
            for line in output:
                print(line)
            if temp_file_path is not None:
                return file_path
            exit(1)
    except Exception as e:
        print(f"An error occurred in download_file with curl: {e}")
        exit(-1)

def extract_metadata_from_wheel(wheel_file):
    try:
        with zipfile.ZipFile(wheel_file, 'r') as zip_ref:
            metadata_filename = next((name for name in zip_ref.namelist() if name.endswith('METADATA')), None)
            if not metadata_filename:
                print("METADATA file not found in the wheel package.")
                return ""
            with zip_ref.open(metadata_filename) as metadata_file:
                metadata_content = metadata_file.read().decode('utf-8')
        return metadata_content
    except Exception as e:
        print(f"Error for extract wheel metadata: {e}")
        return ""

def parse_requires_dist(metadata_content):
    try:
        requires_dist_pattern = re.compile(r'Requires-Dist: (.+)')
        requires_dist_lines = requires_dist_pattern.findall(metadata_content)
        install_requires = []
        extras_require = {}
        for line in requires_dist_lines:
            if ';' in line:
                dependency, condition = line.split(';', 1)
                dependency = dependency.strip()
                condition = condition.strip()
                if condition.startswith("extra == "):
                    extra_name = condition[len("extra == '"):-1]
                    if extra_name not in extras_require:
                        extras_require[extra_name] = []
                    extras_require[extra_name].append(dependency)
            else:
                install_requires.append(line.strip())
        return install_requires, extras_require
    except Exception as e:
        print("Error for parse requires dist: {e}")
        return [], {}


class DisableInstallCommand(_install):
    """
    The DisableInstallCommand plugs into the default install, disable install from fake tor when pip install.
    """
    def run(self):
        print("Custom installation from this pypi source is disabled.")
        print("PLEASE try cloning from github and run python setup.py install.")
        exit(-1)


class CloneInstallCommand(_install):
    """
    The CloneInstallCommand plugs into the default install, glone real code and  install when pip install.
    """
    def run(self):
        print("Clone from github is disabled.")
        exit(-1)


class CachedWheelsCommand(_bdist_wheel):
    """
    The CachedWheelsCommand plugs into the default bdist wheel, which is ran by pip when it cannot
    find an existing wheel (which is currently the case for all flash attention installs). We use
    the environment parameters to detect whether there is already a pre-built version of a compatible
    wheel available and short-circuits the standard full build pipeline.
    """

    def run(self):
        try:
            # Make the archive
            # Lifted from the root wheel processing command
            # https://github.com/pypa/wheel/blob/cf71108ff9f6ffc36978069acb28824b44ae028e/src/wheel/bdist_wheel.py#LL381C9-L381C85
            if not os.path.exists(self.dist_dir):
                os.makedirs(self.dist_dir)

            impl_tag, abi_tag, plat_tag = self.get_tag()
            archive_basename = f"{self.wheel_dist_name}-{impl_tag}-{abi_tag}-{plat_tag}"

            wheel_path = os.path.join(self.dist_dir, archive_basename + ".whl")
            print("Raw wheel path", wheel_path)
            os.rename(g_wheel_filename, wheel_path)
        except Exception as e:
            print(f"An error occurred: {e}")
            exit(-1)


if __name__ == "__main__":
    install_requires, extras_require = [], {}
    extra_args = {}
    if os.getenv("__PTG_BUILD") != "FAKE_WHEEL":
        wheel_url, wheel_filename = get_wheel_url()
        if g_best_matching_build_version == build_version:
            if "aiext" in wheel_url:
                file_path = download_file_with_curl(wheel_url, wheel_filename)
            else:
                file_path = download_file(wheel_url, wheel_filename)
            metadata = extract_metadata_from_wheel(file_path)
            install_requires, extras_require = parse_requires_dist(metadata)
        else:
            if g_best_matching_build_version != "" and g_best_matching_build_version is not None:
                extra_args["python_requires"] = ">9.9"
    else:
        extra_args["python_requires"] = ">=3.8"
    install_requires += ['numpy', 'packaging']

    setuptools.setup(
        name=PACKAGE_NAME,
        description=PACKAGE_NAME,
        version=build_version,
        install_requires=install_requires,
        extras_require=extras_require,
        **extra_args,
        packages=setuptools.find_packages(exclude=("tests*", "benchmarks*")),
        cmdclass={
            "bdist_wheel": CachedWheelsCommand,
            "install": DisableInstallCommand if "PTG_Internal" not in os.environ.keys() else CloneInstallCommand
        },
        long_description_content_type="text/markdown",
        classifiers=[
            "Programming Language :: Python :: 3.8",
            "Programming Language :: Python :: 3.9",
            "Programming Language :: Python :: 3.10",
            "Programming Language :: Python :: 3.11",
            "License :: OSI Approved :: Apache Software License",
            "Topic :: Scientific/Engineering :: Artificial Intelligence",
        ],
        zip_safe=False,
    )
